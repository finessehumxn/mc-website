BID-IN-A-BOX by Millennials Creatives LLC
Thank you for your purchase! 12 working files inside:

THE PLAYBOOK
  Bid-in-a-Box-Playbook.pdf . . . the complete 13-part system. Start here.

7 EDITABLE WORD TEMPLATES (fill the pink brackets, delete the gray instructions)
  Proposal-Cover-Letter-Template.docx
  Technical-Approach-Template.docx . . . includes the shall-by-shall compliance table
  Past-Performance-Template.docx
  Price-Volume-Template.docx
  Sources-Sought-Response-Template.docx . . . the set-aside trigger letter
  Contingent-Team-Agreement-Template.docx . . . SAMPLE, have your attorney review
  Capability-Statement-Template.docx . . . make a federal AND a state version

THE WORKING TOOLS
  bid-tracker.csv . . . pipeline tracker, 2 example rows included, replace them
  pricing-worksheet.csv . . . fill EVERY line before quoting
  email-templates.txt . . . 5 copy-paste emails for contracting officers

FIRST HOUR: read Playbook Parts 1-3, open the tracker, book your free APEX
Accelerator session (apexaccelerators.us).
Support: contact@millennialscreatives.com (same-day on business days).
Want it done for you? millennialscreatives.com
