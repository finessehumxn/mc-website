GRANT READINESS: THE COURSE KIT
Millennials Creatives LLC · millennialscreatives.com

The course is free to read at millennialscreatives.com/course-grant-readiness
This kit is the arsenal that puts it to work:

1. Readiness-Pipeline-Budget.xlsx
   Three tabs: readiness scorecard with an honest verdict formula,
   grant pipeline with deadline countdowns, and a program budget that checks its own math.
2. Boilerplate-Library.docx, the six blocks that prewrite 60% of every application
3. Letter-of-Inquiry-Template.docx, the one-page door-opener

Pairs with MCGrants, the winnability engine: millennialscreatives.com/mcgrants
Questions: contact@millennialscreatives.com
