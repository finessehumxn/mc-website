WORKPLACE SAFETY ESSENTIALS: THE COURSE KIT
Millennials Creatives LLC · millennialscreatives.com

The course is free to read at millennialscreatives.com/course-workplace-safety
This kit is the arsenal that puts it to work:

1. Hazard-Assessment-and-Training-Tracker.xlsx
   Two tabs: walk-through hazard assessment with auto risk scoring,
   and a training tracker with automatic renewal countdowns.
2. Incident-Report-Template.docx, the 24-hour incident record
3. Toolbox-Talk-Template.docx, the 10-minute weekly briefing script
4. 90-Day-Safety-Program-Plan.docx, zero to a working program in one quarter

Questions or corporate training (live, $497/session): contact@millennialscreatives.com
